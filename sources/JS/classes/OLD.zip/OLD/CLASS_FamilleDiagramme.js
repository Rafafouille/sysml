


//=================================================
// Constructeur
//=================================================
function FamilleDiagrammes(_titre_,_x_,_y_)
{
	//Héritage *************************
		createjs.Container.call(this);
	
	//Membres **************************
		//Graphismes
		this._titre=_titre_;
		this._taillePoliceTitre=13;
		this._margeTitreVert=15;
		this._margeTitreHorz=30;
		this._x0=_x_;
		this._y0=_y_;
		this._width0=this._taillePoliceTitre*0.52*this._titre.length+2*this._margeTitreHorz,
		this._height0=this._taillePoliceTitre+this._margeTitreVert*2;
		this._couleur="#ffeecd";
		//etat
		this._estOuvert=false;
		this._tempsOuvrirFermer=500;	//Temps d'animation d'ouverture/fermeture
		//Diagrammes
		this._listeDiagrammes=[];
		this._margeDiagrammesHorz=20;
		this._margeDiagrammesVert=20;

	
	
	//Graphiques *******************************
	
		this.texte=new createjs.Text(this._titre,this._taillePoliceTitre.toString()+"px Arial");
		this.texte.textAlign = 'center';
		this.texte.textBaseline = 'middle';
		
		this.cadre=new createjs.Shape();
		this.cadre.graphics.setStrokeStyle(1);
		this.cadre.graphics.beginStroke('black');
		this.cadre.graphics.beginFill(this._couleur);
		this.cadre.rectangle=this.cadre.graphics.drawRoundRect (-this._width0/2,-this._height0/2,this._width0,this._height0,5).command;
		this.cadre.graphics.endFill();
		
		this.groupeDiagrammes=new createjs.Container();
		
		this.menu=new MenuIcones();
		
		this.addChild(this.cadre);
		this.addChild(this.texte);
		this.addChild(this.groupeDiagrammes);
		this.addChild(this.menu);
	
	//Autre **********************************
	this.x=this._x0;
	this.y=this._y0;
	this.cursor = "pointer";
	
	
	//Evénement *******************************
	this.on("click",function(evt)
						{
							$("#boite_pas_implemente").dialog("open");
							//this.ouvrirFermer();
						});
}
//Héritage du prototype
FamilleDiagrammes.prototype = Object.create(createjs.Container.prototype);



//=================================================
// getters / setters
//=================================================



FamilleDiagrammes.prototype.x0=function(X)
{
	if(typeof(X)!="undefined")
		this._x0=X;
	return this._x0;
}
FamilleDiagrammes.prototype.y0=function(Y)
{
	if(typeof(Y)!="undefined")
		this._y0=Y;
	return this._y0;
}
FamilleDiagrammes.prototype.titre=function(t)
{
	if(typeof(t)!="undefined")
		this._titre=t;
	return this._titre;
}


//=================================================
//Fonctions membres
//=================================================

//Ouvrir la fenetre **************
FamilleDiagrammes.prototype.ouvrir=function()
{
	this._estOuvert=true;	//Tag ouvert
	SCENE.setChildIndex(this,SCENE.getNumChildren()-1);//Mettre en avant plan
	createjs.Tween.get(this,{override:true})	//Animation...
		.to({ x: 0, y:0 }, this._tempsOuvrirFermer,createjs.Ease.quadInOut)
		.call(function(){this.menu.ouvrir();//Ouvrir le menu aprés l'animation
						this.menu.x=40;
						this.menu.y=40;
						this.groupeDiagrammes.visible=true;
						});
	createjs.Tween.get(this.cadre.rectangle)
		.to({x:20,y:+20,w:SCENE.canvas.width-40,h:SCENE.canvas.height-40},this._tempsOuvrirFermer,createjs.Ease.quadInOut);
	createjs.Tween.get(this.texte)
		.to({x:SCENE.canvas.width/2,y:10+20}, this._tempsOuvrirFermer,createjs.Ease.quadInOut)
		
	this.removeAllEventListeners("click");//Supprime le click
	this.cursor = "default";
}

//Ferme la fenetre ***************************
FamilleDiagrammes.prototype.fermer=function()
{
	this._estOuvert=false;
	this.menu.fermer();
	this.groupeDiagrammes.visible=true;
	createjs.Tween.get(this,{override:true})
		.to({x:this._x0, y:this._y0 }, this._tempsOuvrirFermer,createjs.Ease.quadInOut)
		.call(function(){
						this.on("click",this.ouvrir); //Remet le click pour ouvrir
						this.cursor = "pointer"
						});
	createjs.Tween.get(this.cadre.rectangle)
		.to({x:-this._width0/2,y:-this._height0/2,w:this._width0,h:this._height0},this._tempsOuvrirFermer,createjs.Ease.quadInOut);
	createjs.Tween.get(this.texte)
		.to({x:0,y:0}, this._tempsOuvrirFermer,createjs.Ease.quadInOut);
		
}

//Ouvrir/Fermer la fenetre ********************
FamilleDiagrammes.prototype.ouvrirFermer=function()
{
	if(this._estOuvert)
		this.fermer();
	else
		this.ouvrir();
}


//Ajouter un diagramme **************************
FamilleDiagrammes.prototype.addDiagramme=function(diag)
{
	this._listeDiagrammes.push(diag);
	this.groupeDiagrammes.addChild(diag);
	this.updatePositionDiagrammes();
}

//Repositionne les diagrammes ************************
FamilleDiagrammes.prototype.updatePositionDiagrammes=function()
{
	var posX=20+this._margeDiagrammesHorz;//Position initiale
	var posY=this.menu.y+this.menu.getBounds().height+this._margeDiagrammesVert;
	var hauteurMax=0;
	for(var i=0;i<this._listeDiagrammes.length;i++)
	{
		var diag=this._listeDiagrammes[i];
		a=diag;
		diag.x=posX;
		diag.y=posY;
		
		if(hauteurMax<diag.getBounds().height)
			hauteurMax=diag.getBounds().height;
		
		posX+=diag.getBounds().width;
		
		if(posX>SCENE.getBounds().width-2*this._margeDiagrammesHorz)
		{
			posX=20+this._margeDiagrammesHorz;
			posY+=hauteurMax;
		}
	}
}
