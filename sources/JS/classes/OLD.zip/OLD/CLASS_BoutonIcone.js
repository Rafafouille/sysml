//=================================================
// Constructeur
//=================================================
function BoutonIcone(_fonction_,_listeOptions_)
{
	
	//Parametres par defaut
	if(typeof _fonction_=="undefined")
		_fonction_=null;
	if(typeof _listeOptions_=="undefined")
		_listeOptions_={};
	if(typeof _listeOptions_.width == "undefined")
		_listeOptions_.width=32;
	if(typeof _listeOptions_.height == "undefined")
		_listeOptions_.height=32;
	if(typeof _listeOptions_.texte == "undefined")
		_listeOptions_.texte="+";
	if(typeof _listeOptions_.image == "undefined")
		_listeOptions_.image="";
	if(typeof _listeOptions_.cadre == "undefined")
		_listeOptions_.cadre=true;
	if(typeof _listeOptions_.contexte == "undefined")
		_listeOptions_.contexte=null;
	
	
	
	//Héritage *************************
	createjs.Container.call(this);
	
	//Membres **************************
	this._fonction=_fonction_; //Fonction à exécuter au moment du clic;
	this._width=_listeOptions_.width;
	this._height=_listeOptions_.height;
	this._texte=_listeOptions_.texte;
	this._image=_listeOptions_.image;
	this._actif=false;
	this._cadre=_listeOptions_.cadre;
	this._contexte=_listeOptions_.conctexte;
	
	
	
	//Graphiques *******************************
	this.cadre=new createjs.Shape();
	if(this._cadre)
	{
		this.cadre.graphics.setStrokeStyle(1);
		this.cadre.graphics.beginStroke('black');
		this.cadre.graphics.drawRoundRect(0,0,this._width,this._height,2);
		this.cadre.graphics.endFill();
	}
	this.cadre.cursor = "pointer";
	
	if(this._image!="")
	{
		this.icone=new createjs.Bitmap(this._image);
	}
	
	
	this.shadow=new createjs.Shadow("#000000",2,2,6);
	
	this.addChild(this.icone);
	this.addChild(this.cadre);

	//Autre **********************************

	this.setBounds(0,0,this._width,this._height);
	this.cursor = "pointer";

	//Evénement *******************************
	this.removeAllEventListeners("click");
	
	if(this._contexte==null)
		this.on("click",this._fonction);
	else
		this.on("click",this.fonctionWithContext);
	

}
//Héritage du prototype
BoutonIcone.prototype = Object.create(createjs.Container.prototype);






//=================================================
// Méthodes
//=================================================

BoutonIcone.prototype.fonctionWithContext=function()
{
	this._function.call(this._context);
}
