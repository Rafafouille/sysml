

//=================================================
// Constructeur
//=================================================
function FamilleReq(_x_,_y_)
{
	//Héritage *************************
	FamilleDiagrammes.call(this,"Diagrammes d'exigences",_x_,_y_);
	
	//Membres **************************
	
	//Graphiques *******************************
	this.menu.boutonFermer=new BoutonIcone(this.fermer.bind(this),{image:"./sources/images/icone-fermer.png",cadre:false})
	this.menu.boutonAjouter=new BoutonIcone(this.addDiagrammeReq.bind(this),{image:"./sources/images/icone-ajouter.png",cadre:false});
	this.menu.addBouton(this.menu.boutonFermer);
	this.menu.addBouton(this.menu.boutonAjouter);


	//Autre **********************************

	//Evénement *******************************
	this.removeAllEventListeners("click");
		
	this.on("click",this.ouvrir);
}
//Héritage du prototype
FamilleReq.prototype = Object.create(FamilleDiagrammes.prototype);




//=================================================
//Fonctions membres
//=================================================


//Nouveau diagramme d'exigences *********
FamilleReq.prototype.addDiagrammeReq=function()
{
	var diag=new DiagrammeReq("Nouveau Diagramme");
	this.addDiagramme(diag);
}
