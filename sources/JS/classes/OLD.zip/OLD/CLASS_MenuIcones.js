

//=================================================
// Constructeur
//=================================================
function MenuIcones()
{
	//Héritage *************************
	createjs.Container.call(this);
	this.visible=false;
	
	
	//Membres **************************
	this._listeBoutons=[];
	this._ouvert=false;
	
	//Graphiques *******************************

	

	//Autre **********************************


	//Evénement *******************************
	this.removeAllEventListeners("click");
	

}
//Héritage du prototype
MenuIcones.prototype = Object.create(createjs.Container.prototype);



//=================================================
// Méthodes
//=================================================

//Renvoi le dernier bouton
MenuIcones.prototype.lastBouton=function()
{
	return this._listeBoutons[this._listeBoutons.length-1];
}

//Ajoute un bouton
MenuIcones.prototype.addBouton=function(_bouton)
{
	this.addChild(_bouton);
	_bouton.y=0;
	if(this._listeBoutons.length>0)
		_bouton.x=this.lastBouton().x+this.lastBouton().getBounds().width;
	else
		_bouton.x=0;
		
	this._listeBoutons.push(_bouton);
}


//Ouvrir
MenuIcones.prototype.ouvrir=function()
{
	this.visible=true;
	this._ouvert=true;
}

//Fermer
MenuIcones.prototype.fermer=function()
{
	this.visible=false;
	this._ouvert=false;
	SCENE.update();
}


